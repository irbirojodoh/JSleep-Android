package com.RijalJSleepFN.model;
public enum BedType {
    SINGLE,QUEEN,KING,DOUBLE;
    
}
