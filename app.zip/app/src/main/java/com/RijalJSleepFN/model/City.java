package com.RijalJSleepFN.model;
public enum City {
    SURABAYA,DEPOK,LAMPUNG,JAKARTA,BANDUNG,SEMARANG,MEDAN,BEKASI,BALI
    
}
