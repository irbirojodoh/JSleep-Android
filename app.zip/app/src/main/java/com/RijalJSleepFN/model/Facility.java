package com.RijalJSleepFN.model;

public enum Facility {
        WiFi,Baththub,Balcony,
        AC,FitnessCenter,Refrigerator,
        Restaurant,SwimmingPool
    }
    

